//40223086mobinapeymani
#include<stdio.h>

 struct time {
    int min;
    int sec;
 };
 
 struct runner{
    char first_name[20];
    char last_name[20];
    int ID;
    struct time running_time;
    struct time *record ;
 };
 

 int main(){
int n ;
printf("enter the number of runners :");
scanf("%d", &n);
int saved_time[n];
struct time best_record;
//struct runner x;
struct runner a[n];
//x.record=&best_record;
for(int i = 0 ; i<n ; i++){
   printf("f, l, id,persent, best :");
   scanf("%s", a[i].first_name);
   scanf("%s", a[i].last_name);
   scanf("%d", &a[i].ID);
   scanf("%d", &a[i].running_time.min);
   scanf("%d", &a[i].running_time.sec);
   a[i].record= &best_record;
   scanf("%d", &a[i].record->min);
    scanf("%d", &a[i].record->sec);

}
for(int j = 0 ; j<n ; j++ ){
   saved_time[j]=(a[j].running_time.min*60) + a[j].running_time.sec;
}
int size = sizeof(saved_time)/sizeof(saved_time[0]);
int min = saved_time[0];
int index = 0;
for(int y = 1 ; y<size; y++){
   if(saved_time[y]<min){
      min = saved_time[y];
      index = y;
   }

}
printf(" the winner : %s%4s\n",a[index].first_name,a[index].last_name);
int record_1 = a[index].record->min*60 + a[index].record->sec;
if (record_1>saved_time[index])
  printf("broke\n");
else 
 printf("not broke\n");
int record_2 [n];
   int flag = 0;
for(int k = 0 ; k<n ; k++){
  record_2 [k] = a[k].record->min*60 + a[k].record->sec;
 if(record_1<record_2[k])
  flag = 1 ;
break;  
}
if(flag== 1 )
 printf(" he cant \n");
else 
printf("he can\n");


printf("first name       lastname       ID       runningtime       record\n");
 for(int i = 0 ; i<n-1 ; i++){
     for(int x = 0 ; x<n-1 - i; x++)
     if (saved_time[x]>saved_time[x+1]){
        int hold = saved_time[x];
        saved_time[x]= saved_time[x+1];
        saved_time[x+1]=hold;
     }        
 }
 for(int k = 0 ; k<n ; k++){
  record_2 [k] = a[k].record->min*60 + a[k].record->sec;}
 for(int y = 0 ; y<n ; y++){
  printf("%s       %s       %d       %d       %d\n",a[y].first_name, a[y].last_name,a[y].ID,saved_time[y],record_2[y]);
 }

//printf("hfghfsdgkj");
   return 0;
 }
 